<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>My test page</title>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href="styles/style.css" rel="stylesheet" type="text/css">
  </head>
  <body>
    <h1>My PHP Website #1</h1>
    <img src="http://php.net/images/logos/new-php-logo.png" alt="PHP Logo">

    <p>We are live!</p>
    
    <ul> <!-- changed to list in the tutorial -->
      <li>Time: <?php echo "Today is " . date("Y/m/d") ?></li>
    </ul>


  </body>
</html>